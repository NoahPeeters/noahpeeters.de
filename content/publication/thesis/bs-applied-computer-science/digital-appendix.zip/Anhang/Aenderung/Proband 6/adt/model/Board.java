package de.noahpeeters.gameoflife.adt.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Board implements InfiniteCellGrid {
    private final Set<CellPosition> aliveCells;
    private Map<CellPosition, Integer> roundsAlive;

    private Board(Set<CellPosition> aliveCells) {
        this.aliveCells = aliveCells;
        this.roundsAlive = new HashMap<>();
    }

    public Board(Set<CellPosition> aliveCells, Map<CellPosition, Integer> roundsAlive) {
        this.aliveCells = aliveCells;
        this.roundsAlive = roundsAlive;
    }

    public static Board empty() {
        return new Board(new HashSet<>());
    }

    public boolean isAlive(CellPosition position) {
        return aliveCells.contains(position);
    }

    public void markAsAlive(CellPosition position) {
        if (!aliveCells.contains(position)) {
            Integer cellRoundsAlive = roundsAlive.getOrDefault(position, 0);
            roundsAlive.put(position, cellRoundsAlive + 1);
        }
        aliveCells.add(position);
    }

    public void markAsDead(CellPosition position) {
        aliveCells.remove(position);
    }

    public Board createCopy() {
        return new Board(new HashSet<>(aliveCells), new HashMap<>(roundsAlive));
    }

    @Override
    public Map<CellPosition, Integer> getRoundsAlive() {
        return roundsAlive;
    }

    public Set<CellPosition> getActivePositions() {
        Set<CellPosition> neighbours = aliveCells
                .stream()
                .flatMap(position -> position.getNeighbours().stream())
                .collect(Collectors.toSet());
        neighbours.addAll(aliveCells);
        return neighbours;
    }

    public Set<CellPosition> getAliveCells() {
        return aliveCells;
    }
}
