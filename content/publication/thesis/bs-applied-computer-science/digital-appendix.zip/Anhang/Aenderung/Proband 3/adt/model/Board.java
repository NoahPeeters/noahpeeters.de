package de.noahpeeters.gameoflife.adt.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Board implements InfiniteCellGrid {
    private final Set<CellPosition> aliveCells;
    private final Map<CellPosition, Integer> aliveStatusCount;

    private Board(
        Set<CellPosition> aliveCells,
        final Map<CellPosition, Integer> aliveStatusCount
    ) {
        this.aliveCells = aliveCells;
        this.aliveStatusCount = aliveStatusCount;
    }

    public static Board empty() {
        return new Board(new HashSet<>(), new HashMap<>());
    }

    public boolean isAlive(CellPosition position) {
        return aliveCells.contains(position);
    }

    public void markAsAlive(CellPosition position) {
        aliveCells.add(position);
        aliveStatusCount.compute(position, (key, value) -> value == null ? 1 : value + 1);
    }

    public void markAsDead(CellPosition position) {
        aliveCells.remove(position);
    }

    public Board createCopy() {
        return new Board(new HashSet<>(aliveCells), new HashMap<>(aliveStatusCount));
    }

    public Set<CellPosition> getActivePositions() {
        Set<CellPosition> neighbours = aliveCells
                .stream()
                .flatMap(position -> position.getNeighbours().stream())
                .collect(Collectors.toSet());
        neighbours.addAll(aliveCells);
        return neighbours;
    }

    @Override
    public int getAliveCount(final CellPosition position) {
        return this.aliveStatusCount.getOrDefault(position, 0);
    }
}
