package de.noahpeeters.gameoflife.adt.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Board implements InfiniteCellGrid {

    private final Set<CellPosition> aliveCells;

    private Map<CellPosition, Integer> aliveMap;

    private Board(Set<CellPosition> aliveCells, Map<CellPosition, Integer> aliveMap) {
        this.aliveCells = aliveCells;
        this.aliveMap = aliveMap;
    }

    public static Board empty() {
        return new Board(new HashSet<>(), new HashMap<>());
    }

    public boolean isAlive(CellPosition position) {
        return aliveCells.contains(position);
    }

    public void markAsAlive(CellPosition position) {
        if (!isAlive(position)) {
           aliveMap.put(position, aliveMap.getOrDefault(position, 0) + 1);
        }
        aliveCells.add(position);
    }

    public void markAsDead(CellPosition position) {
        aliveCells.remove(position);
    }

    @Override
    public int wasAliveCount(final CellPosition position) {
        return aliveMap.getOrDefault(position, 0);
    }

    @Override
    public long aliveCount() {
        return aliveCells.size();
    }

    public Board createCopy() {
        return new Board(new HashSet<>(aliveCells), aliveMap);
    }

    public Set<CellPosition> getActivePositions() {
        Set<CellPosition> neighbours = aliveCells
                .stream()
                .flatMap(position -> position.getNeighbours().stream())
                .collect(Collectors.toSet());
        neighbours.addAll(aliveCells);
        return neighbours;
    }
}
