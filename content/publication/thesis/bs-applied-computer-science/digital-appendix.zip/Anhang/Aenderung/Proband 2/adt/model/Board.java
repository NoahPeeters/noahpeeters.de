package de.noahpeeters.gameoflife.adt.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Board implements InfiniteCellGrid {
    private final Set<CellPosition> aliveCells;
    private final Map<CellPosition, Integer> aliveCount;

    private Board(Set<CellPosition> aliveCells, Map<CellPosition, Integer> aliveCount) {
        this.aliveCells = aliveCells;
        this.aliveCount = aliveCount;
    }

    public static Board empty() {
        return new Board(new HashSet<>(), new HashMap<>());
    }

    public boolean isAlive(CellPosition position) {
        return aliveCells.contains(position);
    }

    public void markAsAlive(CellPosition position) {
        if (aliveCells.add(position)) {
            aliveCount.merge(position, 1, Integer::sum);
        }
    }

    public void markAsDead(CellPosition position) {
        aliveCells.remove(position);
    }

    public Board createCopy() {
        return new Board(new HashSet<>(aliveCells), new HashMap<>(aliveCount));
    }

    public int aliveCellCount() {
        return aliveCells.size();
    }

    public int aliveCountForCell(CellPosition position) { return aliveCount.getOrDefault(position, 0); }

    public Set<CellPosition> getActivePositions() {
        Set<CellPosition> neighbours = aliveCells
                .stream()
                .flatMap(position -> position.getNeighbours().stream())
                .collect(Collectors.toSet());
        neighbours.addAll(aliveCells);
        return neighbours;
    }
}
