package de.noahpeeters.gameoflife.classic.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Board {
    private final Set<CellPosition> aliveCells;
    private Map<CellPosition, Integer> aliveCount;

    public Board(Set<CellPosition> aliveCells, Map<CellPosition, Integer> aliveCount) {
        this.aliveCells = aliveCells;
        this.aliveCount = aliveCount;
    }

    public Board cloneBoard() {
        return new Board(new HashSet<>(this.aliveCells), new HashMap<>(this.aliveCount));
    }

    public void reviveCell(CellPosition position) {
        if (aliveCells.add(position)) {
            System.out.println(position.getX() + " " + position.getY());
            aliveCount.merge(position, 1, Integer::sum);
        }
    }

    public int aliveCount(CellPosition position) {
        return aliveCount.getOrDefault(position, 0);
    }

    public Set<CellPosition> getAliveCells() {
        return aliveCells;
    }

    public Set<CellPosition> getNeighboursOfPosition(CellPosition position) {
        Set<CellPosition> result = new HashSet<>();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx != 0 || dy != 0) {
                    result.add(new CellPosition(position.getX() + dx, position.getY() + dy));
                }
            }
        }
        return result;
    }

    public Set<CellPosition> getActivePositions() {
        Set<CellPosition> neighbours = aliveCells
                .stream()
                .flatMap(position -> getNeighboursOfPosition(position).stream())
                .collect(Collectors.toSet());
        neighbours.addAll(aliveCells);
        return neighbours;
    }
}
