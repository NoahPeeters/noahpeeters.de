package de.noahpeeters.gameoflife.adt.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Board implements InfiniteCellGrid {
    private final Set<CellPosition> aliveCells;
    private final Map<CellPosition, Integer> aliveCounter;

    private Board(Set<CellPosition> aliveCells, Map<CellPosition, Integer> aliveCounter) {
        this.aliveCells = aliveCells;
        this.aliveCounter = aliveCounter;
    }

    public static Board empty() {
        return new Board(new HashSet<>(), new HashMap<>());
    }

    public boolean isAlive(CellPosition position) {
        return aliveCells.contains(position);
    }

    public void markAsAlive(CellPosition position) {
        aliveCells.add(position);
    }

    public void markAsDead(CellPosition position) {
        aliveCells.remove(position);
    }

    public Board createCopy() {
        return new Board(new HashSet<>(aliveCells), new HashMap<>(aliveCounter));
    }

    public int getNumberOfAliveCells() {
        return aliveCells.size();
    }

    public Set<CellPosition> getActivePositions() {
        Set<CellPosition> neighbours = aliveCells
                .stream()
                .flatMap(position -> position.getNeighbours().stream())
                .collect(Collectors.toSet());
        neighbours.addAll(aliveCells);
        return neighbours;
    }

    public void cellBecameAlive(CellPosition cellPosition) {
        aliveCounter.put(cellPosition, aliveCounter.getOrDefault(cellPosition, 0) + 1);
    }

    public Integer getAliveCount(CellPosition cellPosition) {
        return aliveCounter.get(cellPosition);
    }
}
