package de.noahpeeters.gameoflife.adt.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Board implements InfiniteCellGrid {
    private final Set<CellPosition> aliveCells;
    private final Map<CellPosition, Integer> lifeCount;

    private Board(Set<CellPosition> aliveCells) {
        this.aliveCells = aliveCells;
        this.lifeCount = aliveCells.stream().collect(Collectors.toMap(cell -> cell, cell -> 0));
    }

    private Board(Set<CellPosition> aliveCells, Map<CellPosition, Integer> lifeCount) {
        this.aliveCells = aliveCells;
        this.lifeCount = lifeCount;
    }

    public static Board empty() {
        return new Board(new HashSet<>());
    }

    public boolean isAlive(CellPosition position) {
        return aliveCells.contains(position);
    }

    @Override
    public long countLiving() {
        return aliveCells.size();
    }

    public Integer getLifeCount(CellPosition cellPosition) {
        return lifeCount.computeIfAbsent(cellPosition, nonExistant -> 0);
    }

    public void markAsAlive(CellPosition position) {
        aliveCells.add(position);
        lifeCount.merge(position, 1, Integer::sum);
    }

    public void markAsDead(CellPosition position) {
        aliveCells.remove(position);
    }

    public Board createCopy() {
        return new Board(new HashSet<>(aliveCells), new HashMap<>(lifeCount));
    }

    public Set<CellPosition> getActivePositions() {
        Set<CellPosition> neighbours = aliveCells
                .stream()
                .flatMap(position -> position.getNeighbours().stream())
                .collect(Collectors.toSet());
        neighbours.addAll(aliveCells);
        return neighbours;
    }
}
