package de.noahpeeters.gameoflife.classic;

import de.noahpeeters.gameoflife.adt.model.CartesianCellPosition;
import de.noahpeeters.gameoflife.classic.model.Board;
import de.noahpeeters.gameoflife.classic.model.CellPosition;

import java.util.HashSet;
import java.util.Map;
import java.util.stream.Collectors;

public class BoardController {
    private Board board;
    private Map<CellPosition, Integer> lifeCount;


    public BoardController() {
        this.board = new Board(new HashSet<>());

        this.board.getAliveCells().add(new CellPosition(1, 0));
        this.board.getAliveCells().add(new CellPosition(2, 1));
        this.board.getAliveCells().add(new CellPosition(0, 2));
        this.board.getAliveCells().add(new CellPosition(1, 2));
        this.board.getAliveCells().add(new CellPosition(2, 2));
        this.lifeCount= this.board.getAliveCells().stream().collect(Collectors.toMap(cell -> cell, cell -> 1));
    }

    public void step() {
        Board newBoard = new Board(new HashSet<>(board.getAliveCells()));
        for (CellPosition position : board.getActivePositions()) {
            long aliveNeighbourCount = board.getNeighboursOfPosition(position).stream().filter(board.getAliveCells()::contains).count();
            boolean isAlive = board.getAliveCells().contains(position);

            if (isAlive && (aliveNeighbourCount < 2 || aliveNeighbourCount > 3)) {
                newBoard.getAliveCells().remove(position);
            } else if (!isAlive && aliveNeighbourCount == 3) {
                newBoard.getAliveCells().add(position);
                lifeCount.merge(position, 1, Integer::sum);

            }
        }
        this.board = newBoard;
    }

    public void print() {
        for (int y = 0; y < 10; y++) {
            for (int x = 0; x < 10; x++) {
                CellPosition cellPosition = new CellPosition(x, y);
                System.out.print(board.getAliveCells().contains(cellPosition) ? "X" : " ");
            }
            System.out.println();
        }

        long livingCells = board.countAlive();
        System.out.println("----------");
        System.out.println("livingCells = " + livingCells);

        CellPosition cellPosition1 = new CellPosition(0, 0);
        CellPosition cellPosition2 = new CellPosition(3, 2);

        System.out.println("LifeCount(cellPosition1) = " + lifeCount.computeIfAbsent(cellPosition1, nonExistant-> 0));
        System.out.println("LifeCount(cellPosition2) = " + lifeCount.computeIfAbsent(cellPosition2, nonExistant-> 0));
    }
}
