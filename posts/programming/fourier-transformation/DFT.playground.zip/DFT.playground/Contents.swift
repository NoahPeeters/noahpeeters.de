import Foundation

struct SignalPart {
    let frequency: Double
    let amplitude: Double
    let phase: Double
}

func generateDiscreteSignal(numberOfSamplesPerSecond: Int, seconds: Double, signalParts: [SignalPart]) -> [Double] {
    let numberOfSamples = Int(Double(numberOfSamplesPerSecond) * seconds)
    return (0..<numberOfSamples)
        // Calculate the timestamp for each sample
        .map { Double($0) / Double(numberOfSamples - 1) * Double(seconds) }
        // Calculate the signals value fot each timestamp
        .map { (time: Double) -> Double in
            // To calculate the signal value, sum up the values of the different signal parts
            signalParts
                .map { (signalPart: SignalPart) -> Double in
                    sin((signalPart.frequency * time + signalPart.phase) * 2 * Double.pi) * signalPart.amplitude
                }
                .reduce(0, +)
        }
}


let signal = generateDiscreteSignal(numberOfSamplesPerSecond: 50, seconds: 1, signalParts: [
    SignalPart(frequency: 1, amplitude: 1, phase: 0),
    SignalPart(frequency: 5, amplitude: 0.1, phase: 0.25)
])


// Use this to show the Graph using Swift Playgrounds
signal.map() { $0 }


func discreteFourierTransform(signal: [Double], durationInSeconds: Int) -> [SignalPart] {
    let baseFrequency = 1 / Double(durationInSeconds)
    // To calculate all possible frequencies, use the following
    // let frequencies = (0..<signal.count)
    let frequencies = (0..<15)
        .map { Double($0) * baseFrequency }

    let signalParts = frequencies.map { frequency in

        let sinPart = signal.enumerated().map { index, value -> Double in
            let time = Double(index) / Double(signal.count - 1) * Double(durationInSeconds)

            return value * sin(frequency * time * 2 * Double.pi)
        }
            .reduce(0, +)

        let cosPart = signal.enumerated().map { index, value -> Double in
            let time = Double(index) / Double(signal.count - 1) * Double(durationInSeconds)

            return value * cos(frequency * time * 2 * Double.pi)
        }
            .reduce(0, +)

        // Calculate combined sine wave
        let amplitude = sqrt(cosPart*cosPart+sinPart*sinPart)
        let phase = atan2(cosPart, sinPart) / (2 * Double.pi)

        return SignalPart(frequency: frequency, amplitude: amplitude, phase: phase)
    }

    // Normalize amplitude
    return signalParts.map {
        SignalPart(frequency: $0.frequency, amplitude: $0.amplitude / Double(signal.count - 1) * 2, phase: $0.phase)
    }
}

let detectedFrequncies = discreteFourierTransform(signal: signal, durationInSeconds: 1)


// Use this to show the Graph using Swift Playgrounds
detectedFrequncies.map { $0.amplitude }

// Use this to show the Graph using Swift Playgrounds
detectedFrequncies.map { $0.phase }
